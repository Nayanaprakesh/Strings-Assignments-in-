#include <stdio.h>

void reverse_recursive(char str[], int ind, int len);

int main()
{
    char str[30];
    
    
    printf("Enter any string : ");
    scanf("%[^\n]", str);
    
    reverse_recursive(str, ?, ?);
    
    printf("Reversed string is %s\n", str);
}
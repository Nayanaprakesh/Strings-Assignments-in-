#include <stdio.h>

void replace_blank(char []);

int main()
{
    char str[50];
    
    printf("Enter the string with more spaces in between two words\n");
    scanf("%[^\n]", str);
    
    replace_blank(str);
    
    printf("%s\n", str);
}